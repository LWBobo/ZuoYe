package test;

public class Student {
	String name;
	long id;
	public Student() {}
	public Student(String name,long id) {
		this.name=name;
		this.id=id;
	}
}
