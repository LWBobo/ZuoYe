package test;

public class Score {
	//Student stu;
	Course course1;
	Course course2;
	double grade;
	Score(Course course1,Course course2,double grade){
		this.course1=course1;
		this.course2=course2;
		this.grade=grade;
	}
}
