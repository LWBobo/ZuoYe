package test;

public class Course {
	long id;
	String name;
	Course(long id,String name){
		this.id=id;
		this.name=name;
	}
}
