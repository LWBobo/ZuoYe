
public class ShapeTest {

	public static void main(String[] args) {
		Rectangle shap1 = new Rectangle(5, 6);
		Square shap2 = new Square(6);
		System.out.println(shap1.getArea());
		System.out.println(shap2.getArea());

	}

}
